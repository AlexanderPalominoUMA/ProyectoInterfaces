import { useState } from "react";
import { useSound } from "./componentes/SoundContext";
import Loader from "./componentes/Loader";
import MainMenu from "./componentes/MainMenu";
import SettingsMenu from "./componentes/SettingsMenu";
import GameRules from "./componentes/GameRules";
import "./App.css";

function App() {
  const [loading, setLoading] = useState(true);
  const [screen, setScreen] = useState("menu");
  const { volume, setVolume, effects, setEffects, music, setMusic } = useSound();

  if (loading) {
    return <Loader onComplete={() => setLoading(false)} />;
  }

  return (
    <div className="App">
      <header className="App-header">
        {screen === "rules" && <GameRules onBackToMenu={() => setScreen("menu")} onComplete={() => setScreen("game")} />}
        {screen === "game" && <h2>Aquí iría la pantalla del juego</h2>}
        {screen === "settings" && <SettingsMenu onBack={() => setScreen("menu")} />}
        {screen === "menu" && <MainMenu onStartGame={() => setScreen("rules")} onOpenSettings={() => setScreen("settings")} />}
      </header>
      <audio
        src="path_to_game_music.mp3"
        autoPlay
        loop
        volume={music / 100}
      />
    </div>
  );
}

export default App;