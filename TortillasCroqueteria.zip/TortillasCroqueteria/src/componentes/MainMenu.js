import Button from "./Button";
import "../estilos/MainMenu.css";

function MainMenu({ onStartGame, onOpenSettings }) {
  return (
    <div className="App-header">
      <h1>Tortilla's Croqueteria</h1>
      <div className="menu-buttons">
        <Button onClick={onStartGame}>Jugar</Button>
        <Button onClick={onOpenSettings}>Ajustes</Button>
      </div>
      <p className="score">Puntuación más alta: </p>
    </div>
  );
}

export default MainMenu;