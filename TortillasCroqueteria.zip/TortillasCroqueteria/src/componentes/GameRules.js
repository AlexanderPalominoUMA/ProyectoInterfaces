import { useState } from "react";
import "../estilos/GameRules.css";
import Button from "./Button";

function GameRules({ onComplete, onBackToMenu }) {
  const [currentPage, setCurrentPage] = useState(0);
  const [rules] = useState([
    { text: "Regla 1: Usa las teclas para moverte.", image: "/images/regla1.jpg" },
    { text: "Regla 2: Completa el nivel para ganar.", image: "/images/regla2.jpg" }
    //, { text: "Regla 2: Completa el nivel para ganar.", image: "/images/regla2.jpg" }
    // Aqui se pueden agregar las reglas que sean por pagina en principio siguiendo esta estructura
  ]);

  const handleNext = () => {
    if (currentPage < rules.length - 1) {
      setCurrentPage(currentPage + 1);
    } else {
      onComplete();
    }
  };

  const handlePrevious = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="game-rules">
      <h2 className="rules-title">Reglas del Juego</h2>
      <div className="rule-content">
        <p className="rule-text">{rules[currentPage].text}</p>
        {/* <img src={rules[currentPage].image} alt="Regla" className="rule-image" /> */}
      </div>

      <div className="navigation-buttons">
        <Button onClick={handlePrevious} disabled={currentPage === 0}>Anterior</Button>
        <Button onClick={handleNext}>Siguiente</Button>
      </div>
      <Button onClick={handleSkip} className="skip-button">Saltar y Jugar</Button>
      <Button onClick={onBackToMenu} className="back-to-menu">Volver al Menú</Button>
    </div>
  );
}

export default GameRules;
